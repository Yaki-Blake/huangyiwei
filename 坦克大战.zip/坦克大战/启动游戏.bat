@echo off
chcp 65001 >nul
echo ========================================
echo      坦克大战 - HYW原创版本 启动器
echo ========================================
echo.

REM 检查Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未检测到Python，请先安装Python 3.x
    pause
    exit /b 1
)

REM 检查pygame
python -c "import pygame" >nul 2>nul
if %errorlevel% neq 0 (
    echo [提示] 正在安装pygame库...
    pip install pygame
    if %errorlevel% neq 0 (
        echo [错误] pygame安装失败，请手动执行: pip install pygame
        pause
        exit /b 1
    )
)

echo [信息] 正在启动游戏...
echo.
cd /d "%~dp0"
python tank_game.py

REM 如果出错，暂停查看错误
if %errorlevel% neq 0 (
    echo.
    echo [错误] 游戏运行出错，错误代码: %errorlevel%
    pause
)
