# -*- coding: utf-8 -*-
"""
坦克大战游戏 - HYW原创
使用pygame开发
"""

import sys
import os
import math
import random

try:
    import pygame
except ImportError:
    print("[错误] 未检测到pygame库，请先执行: pip install pygame")
    sys.exit(1)

# ==================== 基础配置 ====================
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
TILE_SIZE = 20

# 颜色定义
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 60, 60)
GREEN = (60, 220, 80)
BLUE = (60, 140, 255)
YELLOW = (255, 210, 50)
GRAY = (120, 120, 120)
BROWN = (150, 80, 40)
ORANGE = (255, 140, 0)

# 方向常量
UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3

# ==================== 图形辅助函数 ====================
def load_lizhi_images(target_size):
    """加载 LIZHI.png 并生成存活（原图）和失去（暗色）两种版本"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, 'LIZHI.png')
    try:
        orig = pygame.image.load(path).convert_alpha()
    except Exception:
        return None, None
    
    # 按目标大小等比缩放（保持比例居中）
    orig_w, orig_h = orig.get_size()
    scale = min(target_size / orig_w, target_size / orig_h)
    new_w, new_h = max(1, int(orig_w * scale)), max(1, int(orig_h * scale))
    img_alive = pygame.transform.smoothscale(orig, (new_w, new_h))
    
    # 失去爱心版本：转为暗色（灰度+变暗）
    img_dead = pygame.Surface((new_w, new_h), pygame.SRCALPHA)
    for x in range(new_w):
        for y in range(new_h):
            r, g, b, a = img_alive.get_at((x, y))
            if a > 0:
                gray = int(0.299 * r + 0.587 * g + 0.114 * b)
                dark = max(0, gray // 4)
                img_dead.set_at((x, y), (dark, dark, dark, a))
    
    return img_alive, img_dead


def draw_heart(surface, cx, cy, size, alive=True):
    """保留旧函数作兼容，HUD处已改用LIZHI图标"""
    if alive:
        color_main = (230, 40, 55)
        color_shade = (170, 20, 30)
        color_highlight = (255, 180, 190)
    else:
        color_main = (45, 45, 45)
        color_shade = (20, 20, 20)
        color_highlight = (70, 70, 70)
    w = size
    h = int(size * 0.9)
    r = w // 4
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.circle(s, color_main, (r, r), r)
    pygame.draw.circle(s, color_main, (w - r, r), r)
    tri_points = [(0, r), (w - 1, r), (w // 2, h - 1)]
    pygame.draw.polygon(s, color_main, tri_points)
    pygame.draw.circle(s, color_shade, (r, r), r, 1)
    pygame.draw.circle(s, color_shade, (w - r, r), r, 1)
    pygame.draw.polygon(s, color_shade, tri_points, 1)
    if alive:
        hl_r = max(1, r // 3)
        pygame.draw.circle(s, color_highlight, (r - hl_r, r - hl_r), hl_r)
    surface.blit(s, (cx - w // 2, cy - h // 2))

# ==================== 音效系统 ====================
class SoundManager:
    def __init__(self):
        pygame.mixer.init()
        self.sounds = {}
        base_dir = os.path.dirname(os.path.abspath(__file__))
        sound_files = {
            'shoot': 'shoot.MP3',
            'kill': 'daofangniganma.MP3',
            'die': 'die.mp3'
        }
        for name, filename in sound_files.items():
            filepath = os.path.join(base_dir, filename)
            try:
                self.sounds[name] = pygame.mixer.Sound(filepath)
                self.sounds[name].set_volume(0.6)
            except Exception as e:
                print(f"[警告] 无法加载音效 {filename}: {e}")
                self.sounds[name] = None

    def play(self, name):
        if name in self.sounds and self.sounds[name] is not None:
            try:
                self.sounds[name].play()
            except Exception:
                pass

# ==================== 背景加载 ====================
def load_background():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    bg_path = os.path.join(base_dir, 'beijing.png')
    try:
        bg = pygame.image.load(bg_path).convert()
        return pygame.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except Exception as e:
        print(f"[警告] 无法加载背景图: {e}")
        bg = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        bg.fill((30, 40, 60))
        return bg

# ==================== HYW地图生成 ====================
def generate_hyw_map():
    """
    按Excel表格精确生成 HYW 形状砖墙 + 四周围墙。
    每个单元格 = TILE_SIZE x TILE_SIZE
    """
    obstacles = []
    
    # === 三个字母 ===
    # H: 宽7 — 左右两列 + 中间短横排（缩短横排）
    H_pattern = [
        "1     1",
        "1     1",
        "1     1",
        "1     1",
        "1111111",
        "1111111",
        "1     1",
        "1     1",
        "1     1",
        "1     1",
        "1     1",
        "1     1",
    ]
    
    # Y: 宽7 — 整体左移（缩窄），顶部两峰斜向收拢汇成单列
    Y_pattern = [
        "1     1",
        "1     1",
        " 1   1 ",
        "  1 1  ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
        "   1   ",
    ]
    
    # W: 宽9 — 3峰顶部→斜向内收→中心合并→双V底点（完整W形状）
    W_pattern = [
        "1   1   1",
        "1   1   1",
        "1   1   1",
        "1   1   1",
        " 1  1  1 ",
        " 1  1  1 ",
        "  1 1 1  ",
        "  1 1 1  ",
        "  11 11  ",
        "  1   1  ",
        "  1   1  ",
        "  1   1  ",
    ]
    
    patterns = [H_pattern, Y_pattern, W_pattern]
    pattern_spacing = 2  # 字母之间的间距(格数)
    
    # === 字母居中放置 ===
    cols_total = sum(len(p[0]) for p in patterns) + pattern_spacing * (len(patterns) - 1)
    rows_total = len(H_pattern)  # 12
    total_width_px = cols_total * TILE_SIZE
    total_height_px = rows_total * TILE_SIZE
    
    start_x = (SCREEN_WIDTH - total_width_px) // 2
    start_y = (SCREEN_HEIGHT - total_height_px) // 2
    
    current_x = start_x
    for pattern in patterns:
        rows = len(pattern)
        cols = len(pattern[0])
        for row_idx in range(rows):
            for col_idx in range(cols):
                if pattern[row_idx][col_idx] == '1':
                    x = current_x + col_idx * TILE_SIZE
                    y = start_y + row_idx * TILE_SIZE
                    obstacles.append(pygame.Rect(x, y, TILE_SIZE, TILE_SIZE))
        current_x += cols * TILE_SIZE + pattern_spacing * TILE_SIZE
    
    # === 四周围墙（同颜色砖）===
    # 上方：沿屏幕顶部整行
    for col in range(0, SCREEN_WIDTH, TILE_SIZE):
        obstacles.append(pygame.Rect(col, 0, TILE_SIZE, TILE_SIZE))
    # 下方：沿屏幕底部整行（给操作HUD/底部留0行，直接贴底）
    for col in range(0, SCREEN_WIDTH, TILE_SIZE):
        obstacles.append(pygame.Rect(col, SCREEN_HEIGHT - TILE_SIZE, TILE_SIZE, TILE_SIZE))
    # 左方：整列（跳过已有的上下墙）
    for row in range(TILE_SIZE, SCREEN_HEIGHT - TILE_SIZE, TILE_SIZE):
        obstacles.append(pygame.Rect(0, row, TILE_SIZE, TILE_SIZE))
    # 右方：整列
    for row in range(TILE_SIZE, SCREEN_HEIGHT - TILE_SIZE, TILE_SIZE):
        obstacles.append(pygame.Rect(SCREEN_WIDTH - TILE_SIZE, row, TILE_SIZE, TILE_SIZE))
    
    return obstacles

# 坦克尺寸常量（统一调整）
TANK_SIZE = 30
TANK_TREAD = 6           # 履带宽度
TANK_BODY_OFFSET = 3     # 车身缩进
TANK_TURRET_R = 7        # 炮塔半径
TANK_BARREL_LEN = 16     # 炮管长度
TANK_BARREL_W = 4        # 炮管宽度
BULLET_SIZE = 12         # 子弹(篮球)尺寸

# ==================== 坦克类 ====================
class Tank:
    def __init__(self, x, y, color, is_player=False):
        self.x = x
        self.y = y
        self.width = TANK_SIZE
        self.height = TANK_SIZE
        self.color = color
        self.direction = UP
        self.speed = 3 if is_player else 2
        self.is_player = is_player
        self.health = 3 if is_player else 1
        self.max_health = self.health  # 记录最大血量（用于血条比例）
        self.shoot_cooldown = 0
        self.shoot_delay = 40 if is_player else 60
        self.alive = True
        # AI相关
        self.ai_move_timer = 0
        self.ai_shoot_timer = 0
        # 视觉相关
        self.tread_frame = 0
        self.tread_timer = 0
        
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def can_move(self, new_x, new_y, obstacles, tanks):
        # 边界检查
        if new_x < 0 or new_x + self.width > SCREEN_WIDTH:
            return False
        if new_y < 0 or new_y + self.height > SCREEN_HEIGHT:
            return False
        
        test_rect = pygame.Rect(new_x, new_y, self.width, self.height)
        
        # 障碍物碰撞
        for obs in obstacles:
            if test_rect.colliderect(obs):
                return False
        
        # 其他坦克碰撞
        for tank in tanks:
            if tank != self and tank.alive:
                if test_rect.colliderect(tank.get_rect()):
                    return False
        
        return True
    
    def move(self, direction, obstacles, tanks):
        self.direction = direction
        new_x, new_y = self.x, self.y
        
        if direction == UP:
            new_y -= self.speed
        elif direction == DOWN:
            new_y += self.speed
        elif direction == LEFT:
            new_x -= self.speed
        elif direction == RIGHT:
            new_x += self.speed
        
        if self.can_move(new_x, new_y, obstacles, tanks):
            self.x = new_x
            self.y = new_y
            # 更新履带动画帧
            self.tread_timer += 1
            if self.tread_timer >= 6:
                self.tread_timer = 0
                self.tread_frame = (self.tread_frame + 1) % 2
            return True
        return False
    
    def can_shoot(self):
        if self.shoot_cooldown > 0:
            return False
        return True
    
    def shoot(self, sound_mgr):
        if not self.can_shoot():
            return None
        self.shoot_cooldown = self.shoot_delay
        sound_mgr.play('shoot')
        
        # 计算子弹初始位置（坦克炮口）
        bullet_size = BULLET_SIZE
        cx = self.x + self.width // 2
        cy = self.y + self.height // 2
        
        if self.direction == UP:
            bx = cx - bullet_size // 2
            by = self.y - bullet_size
        elif self.direction == DOWN:
            bx = cx - bullet_size // 2
            by = self.y + self.height
        elif self.direction == LEFT:
            bx = self.x - bullet_size
            by = cy - bullet_size // 2
        else:  # RIGHT
            bx = self.x + self.width
            by = cy - bullet_size // 2
        
        return Bullet(bx, by, self.direction, self.is_player, bullet_size)
    
    def update(self, obstacles, tanks, bullets, player_tank, sound_mgr):
        # 射击冷却
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        
        if not self.is_player and self.alive:
            self.ai_update(obstacles, tanks, bullets, player_tank, sound_mgr)
    
    def ai_update(self, obstacles, tanks, bullets, player_tank, sound_mgr):
        """敌方AI逻辑"""
        self.ai_move_timer += 1
        self.ai_shoot_timer += 1
        
        # 每1.5秒尝试转向
        if self.ai_move_timer > 90:
            self.ai_move_timer = 0
            # 偏向朝向玩家
            if player_tank and player_tank.alive and random.random() < 0.5:
                dx = player_tank.x - self.x
                dy = player_tank.y - self.y
                if abs(dx) > abs(dy):
                    self.direction = RIGHT if dx > 0 else LEFT
                else:
                    self.direction = DOWN if dy > 0 else UP
            else:
                self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        
        # 移动
        moved = self.move(self.direction, obstacles, tanks)
        if not moved:
            self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        
        # 射击
        if self.ai_shoot_timer > 80 and self.can_shoot():
            # 如果玩家在射击方向上，提高射击概率
            should_shoot = random.random() < 0.3
            if player_tank and player_tank.alive:
                pr = player_tank.get_rect()
                my_rect = self.get_rect()
                if self.direction == UP and pr.bottom < my_rect.top and abs(pr.centerx - my_rect.centerx) < 60:
                    should_shoot = True
                elif self.direction == DOWN and pr.top > my_rect.bottom and abs(pr.centerx - my_rect.centerx) < 60:
                    should_shoot = True
                elif self.direction == LEFT and pr.right < my_rect.left and abs(pr.centery - my_rect.centery) < 60:
                    should_shoot = True
                elif self.direction == RIGHT and pr.left > my_rect.right and abs(pr.centery - my_rect.centery) < 60:
                    should_shoot = True
            
            if should_shoot:
                bullet = self.shoot(sound_mgr)
                if bullet:
                    bullets.append(bullet)
                self.ai_shoot_timer = 0
    
    def take_damage(self):
        self.health -= 1
        if self.health <= 0:
            self.alive = False
    
    def draw(self, screen):
        if not self.alive:
            return
        rect = self.get_rect()
        
        # 绘制坦克主体（风格化）
        # 履带底盘
        tread_color = (50, 50, 50)
        body_color = self.color
        body_offset = TANK_BODY_OFFSET
        tw = TANK_TREAD
        
        if self.direction in (UP, DOWN):
            # 左右履带
            pygame.draw.rect(screen, tread_color, (rect.x, rect.y, tw, rect.height))
            pygame.draw.rect(screen, tread_color, (rect.right - tw, rect.y, tw, rect.height))
            # 履带花纹
            tread_count = rect.height // 6
            for i in range(tread_count):
                offset_y = rect.y + 3 + i * 6 + (self.tread_frame * 3)
                if offset_y < rect.bottom - 3:
                    pygame.draw.line(screen, (80, 80, 80), 
                                    (rect.x + 1, offset_y), (rect.x + tw - 1, offset_y), 1)
                    pygame.draw.line(screen, (80, 80, 80), 
                                    (rect.right - tw + 1, offset_y), (rect.right - 1, offset_y), 1)
            # 车身
            pygame.draw.rect(screen, body_color, (rect.x + tw, rect.y + body_offset, 
                                                   rect.width - tw * 2, rect.height - body_offset * 2), 
                             border_radius=2)
        else:
            # 上下履带
            pygame.draw.rect(screen, tread_color, (rect.x, rect.y, rect.width, tw))
            pygame.draw.rect(screen, tread_color, (rect.x, rect.bottom - tw, rect.width, tw))
            tread_count = rect.width // 6
            for i in range(tread_count):
                offset_x = rect.x + 3 + i * 6 + (self.tread_frame * 3)
                if offset_x < rect.right - 3:
                    pygame.draw.line(screen, (80, 80, 80), 
                                    (offset_x, rect.y + 1), (offset_x, rect.y + tw - 1), 1)
                    pygame.draw.line(screen, (80, 80, 80), 
                                    (offset_x, rect.bottom - tw + 1), (offset_x, rect.bottom - 1), 1)
            pygame.draw.rect(screen, body_color, (rect.x + body_offset, rect.y + tw, 
                                                   rect.width - body_offset * 2, rect.height - tw * 2),
                             border_radius=2)
        
        # 炮塔（圆形）
        cx, cy = rect.center
        turret_radius = TANK_TURRET_R
        pygame.draw.circle(screen, body_color, (cx, cy), turret_radius)
        pygame.draw.circle(screen, tuple(max(0, c - 30) for c in body_color), (cx, cy), turret_radius, 1)
        
        # 炮管
        barrel_length = TANK_BARREL_LEN
        barrel_width = TANK_BARREL_W
        if self.direction == UP:
            pygame.draw.rect(screen, (40, 40, 40), 
                           (cx - barrel_width // 2, cy - barrel_length, barrel_width, barrel_length))
        elif self.direction == DOWN:
            pygame.draw.rect(screen, (40, 40, 40), 
                           (cx - barrel_width // 2, cy, barrel_width, barrel_length))
        elif self.direction == LEFT:
            pygame.draw.rect(screen, (40, 40, 40), 
                           (cx - barrel_length, cy - barrel_width // 2, barrel_length, barrel_width))
        else:
            pygame.draw.rect(screen, (40, 40, 40), 
                           (cx, cy - barrel_width // 2, barrel_length, barrel_width))
        
        # 玩家标识
        if self.is_player:
            pygame.draw.circle(screen, YELLOW, (cx, cy), 2)
        
        # 血条（敌人）— 每格固定宽度，血越多条越长
        if not self.is_player:
            segment_w = 12  # 每格血条宽度（像素）
            bar_h = 4
            bar_w = max(1, self.max_health) * segment_w
            bar_x = rect.centerx - bar_w // 2
            bar_y = rect.y - 8
            # 背景
            pygame.draw.rect(screen, (80, 0, 0), (bar_x, bar_y, bar_w, bar_h))
            # 当前血量（每格固定宽度）
            hp_w = max(0, self.health) * segment_w
            pygame.draw.rect(screen, RED, (bar_x, bar_y, hp_w, bar_h))
            # 格子分隔线
            for i in range(1, max(1, self.max_health)):
                sx = bar_x + i * segment_w
                pygame.draw.line(screen, (40, 40, 40), (sx, bar_y), (sx, bar_y + bar_h), 1)

# ==================== 子弹类（篮球外观）====================
class Bullet:
    def __init__(self, x, y, direction, from_player, size=BULLET_SIZE):
        self.x = x
        self.y = y
        self.size = size
        self.direction = direction
        self.from_player = from_player  # True=玩家, False=敌人
        self.speed = 7
        self.alive = True
        # 篮球旋转动画
        self.rot_angle = 0
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.size, self.size)
    
    def update(self, obstacles, tanks, debris_list=None):
        if not self.alive:
            return
        
        # 移动
        if self.direction == UP:
            self.y -= self.speed
        elif self.direction == DOWN:
            self.y += self.speed
        elif self.direction == LEFT:
            self.x -= self.speed
        elif self.direction == RIGHT:
            self.x += self.speed
        
        self.rot_angle += 0.3
        
        # 出界
        if (self.x < -self.size or self.x > SCREEN_WIDTH or
            self.y < -self.size or self.y > SCREEN_HEIGHT):
            self.alive = False
            return
        
        # 与障碍物碰撞 → 生成砖碎屑
        my_rect = self.get_rect()
        for obs in obstacles:
            if my_rect.colliderect(obs):
                self.alive = False
                if debris_list is not None:
                    cx = self.x + self.size // 2
                    cy = self.y + self.size // 2
                    for _ in range(8):
                        debris_list.append(BrickDebris(cx, cy))
                return
        
        # 与坦克碰撞
        for tank in tanks:
            if not tank.alive:
                continue
            if self.from_player == tank.is_player:
                continue  # 不打自己人
            if my_rect.colliderect(tank.get_rect()):
                tank.take_damage()
                self.alive = False
                return
    
    def draw(self, screen):
        if not self.alive:
            return
        cx = self.x + self.size // 2
        cy = self.y + self.size // 2
        r = self.size // 2
        
        # 篮球主体（橘黄色）
        pygame.draw.circle(screen, ORANGE, (cx, cy), r)
        # 黑色曲线
        pygame.draw.arc(screen, BLACK, (self.x, self.y, self.size, self.size), 
                       self.rot_angle, self.rot_angle + math.pi, 2)
        pygame.draw.arc(screen, BLACK, (self.x, self.y, self.size, self.size), 
                       self.rot_angle + math.pi, self.rot_angle + math.pi * 2, 2)
        # 十字线
        pygame.draw.line(screen, BLACK, 
                        (cx - r + 1, cy), (cx + r - 1, cy), 1)
        pygame.draw.line(screen, BLACK, 
                        (cx, cy - r + 1), (cx, cy + r - 1), 1)
        # 高光
        pygame.draw.circle(screen, (255, 200, 100), (cx - r // 3, cy - r // 3), r // 4)

# ==================== 爆炸特效 ====================
class Explosion:
    def __init__(self, x, y, size=50):
        self.x = x
        self.y = y
        self.size = size
        self.frame = 0
        self.max_frames = 20
        self.alive = True
    
    def update(self):
        self.frame += 1
        if self.frame >= self.max_frames:
            self.alive = False
    
    def draw(self, screen):
        if not self.alive:
            return
        progress = self.frame / self.max_frames
        current_radius = int(self.size * (0.3 + progress * 0.7))
        alpha = int(255 * (1 - progress))
        
        # 多层爆炸圈
        colors = [
            (255, 100, 0, alpha),
            (255, 200, 0, alpha),
            (255, 255, 100, alpha),
        ]
        cx, cy = self.x, self.y
        for i, col in enumerate(colors):
            r = max(1, current_radius - i * 6)
            surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, col, (r, r), r)
            screen.blit(surf, (cx - r, cy - r))

# ==================== 击杀漂浮文字 ====================
class FloatingText:
    def __init__(self, x, y, text, color=YELLOW):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.life = 60
        self.alive = True
    
    def update(self):
        self.y -= 1
        self.life -= 1
        if self.life <= 0:
            self.alive = False
    
    def draw(self, screen, font):
        if not self.alive:
            return
        alpha = int(255 * (self.life / 60))
        text_surf = font.render(self.text, True, self.color)
        text_surf.set_alpha(alpha)
        screen.blit(text_surf, (self.x - text_surf.get_width() // 2, self.y))


# ==================== 砖块破碎粒子 ====================
class BrickDebris:
    def __init__(self, x, y):
        import random
        colors = [
            (178, 98, 48),
            (148, 78, 38),
            (208, 128, 68),
            (128, 60, 30),
        ]
        self.color = random.choice(colors)
        self.x = x
        self.y = y
        # 向子弹四周随机飞溅
        self.vx = random.randint(-4, 4)
        self.vy = random.randint(-6, 2)
        self.size = random.randint(2, 4)
        self.life = random.randint(18, 32)
        self.alive = True
    
    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 1  # 重力
        self.life -= 1
        if self.life <= 0:
            self.alive = False
    
    def draw(self, screen):
        if not self.alive:
            return
        pygame.draw.rect(screen, self.color,
                         (int(self.x), int(self.y), self.size, self.size))

# ==================== 主游戏类 ====================
class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("坦克大战 - HYW原创")
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True
        
        # 加载资源
        self.background = load_background()
        self.sound_mgr = SoundManager()
        
        # 加载LIZHI图标（替换爱心血条）
        self.lizhi_alive, self.lizhi_dead = load_lizhi_images(36)
        
        # 字体 — 直接用文件路径加载simhei.ttf，避免SysFont静默回退不支持中文
        def load_chinese_font(size):
            # 尝试多个中文字体路径
            font_paths = [
                os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'simhei.ttf'),
                os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'msyh.ttc'),
            ]
            for fp in font_paths:
                if os.path.isfile(fp):
                    try:
                        return pygame.font.Font(fp, size)
                    except Exception:
                        pass
            # 最后回退到SysFont（可能不支持中文）
            return pygame.font.SysFont("simhei,microsoftyahei,simsun", size)
        
        self.font_large = load_chinese_font(48)
        self.font_medium = load_chinese_font(28)
        self.font_small = load_chinese_font(20)
        
        # 游戏对象
        self.obstacles = []
        self.tanks = []
        self.bullets = []
        self.explosions = []
        self.floating_texts = []
        self.brick_debris = []
        
        self.player = None
        self.score = 0
        self.wave = 1
        self.max_wave = 5
        self.enemies_remaining = 0
        self.game_state = "intro"  # intro / playing / win / lose / paused / fade_out / fade_in
        
        # 鼠标控制
        self.mouse_pos = (0, 0)
        self.mouse_down = False
        self.mouse_shoot_cooldown = 0
        
        # === 初始页面(intro)相关 ===
        # HYW墙体（intro和playing共用）
        self.intro_obstacles = generate_hyw_map()
        # 背景游走的人机坦克（自动AI移动，不射击）
        self.intro_wander_tanks = []
        for i in range(3):
            # 在地图右半区随机生成，避免与HYW墙体重叠
            while True:
                tx = random.randint(SCREEN_WIDTH // 2, SCREEN_WIDTH - TANK_SIZE - 30)
                ty = random.randint(80, SCREEN_HEIGHT - TANK_SIZE - 80)
                rect = pygame.Rect(tx, ty, TANK_SIZE, TANK_SIZE)
                collide = any(rect.colliderect(o) for o in self.intro_obstacles)
                if not collide:
                    break
            t = Tank(tx, ty, RED, is_player=False)
            t.shoot_delay = 9999  # 永不射击
            self.intro_wander_tanks.append(t)
        # 左侧固定的激光坦克（1辆，体型放大）
        self.laser_tank = Tank(40, SCREEN_HEIGHT // 2 - TANK_SIZE // 2, BLUE, is_player=False)
        self.laser_tank.speed = 0  # 不移动
        self.laser_tank_scale = 1.8  # 体型放大倍数
        self.lasers = []  # 激光束列表 [{x1,y1,x2,y2}]
        self.laser_cooldown = 0
        # 动画帧
        self.intro_anim_frame = 0
        # 按钮rect — intro页面
        btn_w, btn_h = 200, 50
        btn_y = SCREEN_HEIGHT // 2 + 60
        self.start_btn_rect = pygame.Rect(
            SCREEN_WIDTH // 2 - btn_w - 20, btn_y, btn_w, btn_h)
        self.exit_btn_rect = pygame.Rect(
            SCREEN_WIDTH // 2 + 20, btn_y, btn_w, btn_h)
        # 按钮rect — 暂停页面
        pause_btn_w, pause_btn_h = 180, 45
        pause_btn_y = SCREEN_HEIGHT // 2 + 50
        self.pause_restart_rect = pygame.Rect(
            SCREEN_WIDTH // 2 - pause_btn_w - 15, pause_btn_y, pause_btn_w, pause_btn_h)
        self.pause_menu_rect = pygame.Rect(
            SCREEN_WIDTH // 2 + 15, pause_btn_y, pause_btn_w, pause_btn_h)
        # 黑场动画
        self.fade_alpha = 0
        self.fade_state = None  # None / 'out' / 'in'
        self.fade_callback = None
        self.jiayou_alpha = 0
        self.jiayou_timer = 0
        
        # 鼠标光标隐藏（用自定义瞄准镜绘制）
        pygame.mouse.set_visible(False)
        
        self.init_level()
        # 初始化完成后回到intro状态（玩家先看到初始页面）
        self.game_state = "intro"
    
    def init_level(self):
        self.obstacles = generate_hyw_map()
        self.bullets.clear()
        self.explosions.clear()
        self.floating_texts.clear()
        self.brick_debris.clear()
        self.tanks.clear()
        
        # 玩家坦克（出生在屏幕下方中央）
        px = SCREEN_WIDTH // 2 - TANK_SIZE // 2
        py = SCREEN_HEIGHT - TANK_SIZE - 50
        self.player = Tank(px, py, GREEN, is_player=True)
        self.tanks.append(self.player)
        
        # 生成第一波敌人
        self.spawn_wave()
        self.score = 0
        self.wave = 1
        self.game_state = "playing"
    
    # ==================== 初始页面(intro)逻辑 ====================
    def update_intro(self):
        self.intro_anim_frame += 1
        
        # 背景游走坦克AI移动（不射击）
        for tank in self.intro_wander_tanks:
            # 简单AI：随机转向+移动
            tank.ai_move_timer += 1
            if tank.ai_move_timer > 60:
                tank.ai_move_timer = 0
                tank.direction = random.choice([UP, DOWN, LEFT, RIGHT])
            if not tank.move(tank.direction, self.intro_obstacles, self.intro_wander_tanks):
                tank.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        
        # 激光坦克炮塔跟随鼠标旋转+持续发射激光
        mx, my = self.mouse_pos
        lt = self.laser_tank
        scale = self.laser_tank_scale
        # 放大后的中心位置
        lt_cx = lt.x + lt.width * scale / 2
        lt_cy = lt.y + lt.height * scale / 2
        dx = mx - lt_cx
        dy = my - lt_cy
        dist = math.hypot(dx, dy)
        if dist > 1:
            ux = dx / dist
            uy = dy / dist
            # 炮口位置：从中心沿鼠标方向延伸（炮塔半径+炮管长度）×scale
            barrel_total = (TANK_TURRET_R + TANK_BARREL_LEN) * scale
            muzzle_x = lt_cx + ux * barrel_total
            muzzle_y = lt_cy + uy * barrel_total
            # 持续光束：每帧更新激光位置
            self.lasers = [{
                'x1': muzzle_x, 'y1': muzzle_y,
                'x2': mx, 'y2': my
            }]
        else:
            self.lasers = []
        
        # 黑场动画
        self.update_fade()
    
    def update_fade(self):
        if self.fade_state == 'out':
            self.fade_alpha += 5  # 60帧淡出完成
            if self.fade_alpha >= 255:
                self.fade_alpha = 255
                self.fade_state = 'in'
                self.jiayou_alpha = 255
                self.jiayou_timer = 60  # "加油"显示60帧
                if self.fade_callback:
                    self.fade_callback()
                    self.fade_callback = None
        elif self.fade_state == 'in':
            # "加油"显示期间先不淡入
            if self.jiayou_timer > 0:
                self.jiayou_timer -= 1
                # 后30帧开始淡入黑场
                if self.jiayou_timer < 30:
                    self.fade_alpha -= 9
                    self.jiayou_alpha -= 9
            else:
                self.fade_alpha -= 5
                self.jiayou_alpha = max(0, self.jiayou_alpha - 10)
                if self.fade_alpha <= 0:
                    self.fade_alpha = 0
                    self.fade_state = None
    
    def start_fade_out(self, callback):
        self.fade_state = 'out'
        self.fade_alpha = 0
        self.fade_callback = callback
    
    def draw_intro(self):
        # 背景
        if self.background:
            self.screen.blit(self.background, (0, 0))
        else:
            self.screen.fill((30, 40, 60))
        
        # HYW墙体
        for obs in self.intro_obstacles:
            pygame.draw.rect(self.screen, BROWN, obs)
        
        # 背景游走坦克
        for tank in self.intro_wander_tanks:
            tank.draw(self.screen)
        
        # 激光束（持续光束，红色发光线段）
        for l in self.lasers:
            # 外发光（暗红粗线）
            pygame.draw.line(self.screen, (180, 30, 30),
                           (l['x1'], l['y1']), (l['x2'], l['y2']), 5)
            # 内核（亮红细线）
            pygame.draw.line(self.screen, (255, 200, 200),
                           (l['x1'], l['y1']), (l['x2'], l['y2']), 2)
        
        # 激光坦克（1辆，体型放大，整坦克跟随鼠标旋转）
        lt = self.laser_tank
        scale = self.laser_tank_scale
        cx = lt.x + lt.width * scale / 2
        cy = lt.y + lt.height * scale / 2
        sw = lt.width * scale
        sh = lt.height * scale
        tread_w = TANK_TREAD * scale
        body_offset = TANK_BODY_OFFSET * scale
        turret_r = TANK_TURRET_R * scale
        barrel_len = TANK_BARREL_LEN * scale
        barrel_w = max(2, int(TANK_BARREL_W * scale))
        
        # 计算旋转角度（朝鼠标方向）
        mx, my = self.mouse_pos
        dx = mx - cx
        dy = my - cy
        dist = math.hypot(dx, dy)
        if dist > 1:
            angle = -math.degrees(math.atan2(dy, dx)) - 90
        else:
            angle = 0
        
        # 在临时Surface上画坦克（朝UP方向，居中）
        surf_size = int(max(sw, sh) + barrel_len * 2 + 10)
        tank_surf = pygame.Surface((surf_size, surf_size), pygame.SRCALPHA)
        ts_cx = surf_size // 2
        ts_cy = surf_size // 2
        
        tread_color = (50, 50, 50)
        body_color = lt.color
        # 上下履带
        pygame.draw.rect(tank_surf, tread_color,
                        (ts_cx - sw // 2, ts_cy - sh // 2, sw, tread_w))
        pygame.draw.rect(tank_surf, tread_color,
                        (ts_cx - sw // 2, ts_cy + sh // 2 - tread_w, sw, tread_w))
        # 车身
        pygame.draw.rect(tank_surf, body_color,
                        (ts_cx - sw // 2 + body_offset, ts_cy - sh // 2 + tread_w,
                         sw - body_offset * 2, sh - tread_w * 2),
                        border_radius=3)
        # 炮塔
        pygame.draw.circle(tank_surf, body_color, (ts_cx, ts_cy), int(turret_r))
        pygame.draw.circle(tank_surf, tuple(max(0, c - 30) for c in body_color),
                        (ts_cx, ts_cy), int(turret_r), 2)
        # 炮管（朝上）
        pygame.draw.rect(tank_surf, (40, 40, 40),
                        (ts_cx - barrel_w // 2, ts_cy - turret_r - barrel_len,
                         barrel_w, barrel_len))
        
        # 旋转整个坦克Surface
        rotated = pygame.transform.rotate(tank_surf, angle)
        rect = rotated.get_rect(center=(int(cx), int(cy)))
        self.screen.blit(rotated, rect)
        
        # === 标题滑入动画 ===
        # 标题从屏幕上方滑入到中央偏上位置
        target_y = SCREEN_HEIGHT // 2 - 100
        anim_frames = 60  # 60帧完成滑入
        if self.intro_anim_frame <= anim_frames:
            t = self.intro_anim_frame / anim_frames
            ease = 1 - (1 - t) ** 3  # ease-out cubic
            title_y = -80 + ease * (target_y - (-80))
        else:
            title_y = target_y
        
        # 标题"坦克大战"
        title_surf = self.font_large.render("坦克大战", True, YELLOW)
        title_x = SCREEN_WIDTH // 2 - title_surf.get_width() // 2
        # 标题阴影
        shadow = self.font_large.render("坦克大战", True, BLACK)
        self.screen.blit(shadow, (title_x + 3, title_y + 3))
        self.screen.blit(title_surf, (title_x, title_y))
        
        # 副标题"坤坤版"（黑色）
        subtitle_y = title_y + 70
        subtitle_surf = self.font_medium.render("坤坤版", True, BLACK)
        subtitle_x = SCREEN_WIDTH // 2 - subtitle_surf.get_width() // 2
        self.screen.blit(subtitle_surf, (subtitle_x, subtitle_y))
        
        # === 按钮淡入动画 ===
        btn_alpha = 0
        btn_delay = 80  # 80帧延迟后开始淡入
        btn_frames = 40
        if self.intro_anim_frame > btn_delay:
            t = (self.intro_anim_frame - btn_delay) / btn_frames
            btn_alpha = int(min(255, t * 255))
        
        if btn_alpha > 0:
            # 开始游戏按钮
            start_hover = self.start_btn_rect.collidepoint(self.mouse_pos)
            start_color = (90, 200, 90) if start_hover else (60, 160, 60)
            self._draw_button(self.start_btn_rect, "开始游戏", start_color, btn_alpha)
            # 退出游戏按钮
            exit_hover = self.exit_btn_rect.collidepoint(self.mouse_pos)
            exit_color = (200, 80, 80) if exit_hover else (160, 60, 60)
            self._draw_button(self.exit_btn_rect, "退出游戏", exit_color, btn_alpha)
        
        # 黑场覆盖
        if self.fade_alpha > 0:
            fade_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            fade_surf.fill(BLACK)
            fade_surf.set_alpha(self.fade_alpha)
            self.screen.blit(fade_surf, (0, 0))
        
        # "加油"文字（黑场期间显示）
        if self.jiayou_alpha > 0:
            jiayou_surf = self.font_large.render("加油", True, YELLOW)
            jx = SCREEN_WIDTH // 2 - jiayou_surf.get_width() // 2
            jy = SCREEN_HEIGHT // 2 - jiayou_surf.get_height() // 2
            jiayou_surf.set_alpha(self.jiayou_alpha)
            self.screen.blit(jiayou_surf, (jx, jy))
    
    def _draw_button(self, rect, text, color, alpha):
        btn_surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        # 圆角矩形按钮
        pygame.draw.rect(btn_surf, (color[0], color[1], color[2], alpha),
                         (0, 0, rect.width, rect.height), border_radius=8)
        pygame.draw.rect(btn_surf, (255, 255, 255, alpha),
                         (0, 0, rect.width, rect.height), 2, border_radius=8)
        self.screen.blit(btn_surf, rect.topleft)
        # 按钮文字
        text_surf = self.font_medium.render(text, True, WHITE)
        text_surf.set_alpha(alpha)
        tx = rect.x + (rect.width - text_surf.get_width()) // 2
        ty = rect.y + (rect.height - text_surf.get_height()) // 2
        self.screen.blit(text_surf, (tx, ty))
    
    def spawn_wave(self):
        enemy_count = 2 + self.wave  # 随波次增加
        # 四角生成点，预留空间避免撞墙和HYW地图
        margin = 20
        spawn_points = [
            (margin, margin),                                         # 左上
            (SCREEN_WIDTH - TANK_SIZE - margin, margin),             # 右上
            (margin, SCREEN_HEIGHT // 2 - TANK_SIZE // 2),           # 左中
            (SCREEN_WIDTH - TANK_SIZE - margin, 
             SCREEN_HEIGHT // 2 - TANK_SIZE // 2),                   # 右中
            (SCREEN_WIDTH // 2 - TANK_SIZE // 2, margin),            # 上中
        ]
        spawned = 0
        for pt in spawn_points:
            if spawned >= enemy_count:
                break
            # 检查生成点是否被占用（使用实际坦克尺寸）
            rect = pygame.Rect(pt[0], pt[1], TANK_SIZE, TANK_SIZE)
            collision = False
            for t in self.tanks:
                if t.get_rect().colliderect(rect):
                    collision = True
                    break
            for obs in self.obstacles:
                if rect.colliderect(obs):
                    collision = True
                    break
            if not collision:
                enemy = Tank(pt[0], pt[1], RED, is_player=False)
                # 给后期敌人加血
                if self.wave >= 3:
                    enemy.health = 2
                if self.wave >= 5:
                    enemy.health = 3
                enemy.max_health = enemy.health  # 同步最大血量
                self.tanks.append(enemy)
                spawned += 1
        self.enemies_remaining = spawned
    
    def count_alive_enemies(self):
        count = 0
        for t in self.tanks:
            if not t.is_player and t.alive:
                count += 1
        return count
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.game_state == "playing":
                        self.game_state = "paused"
                    elif self.game_state == "paused":
                        self.game_state = "playing"
                    elif self.game_state in ("win", "lose"):
                        # 重置回intro
                        self.game_state = "intro"
                        self.intro_anim_frame = 0
                        self.fade_alpha = 0
                        self.fade_state = None
                elif event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                    if self.game_state == "intro":
                        # 空格也可触发开始
                        self._on_start_click()
                    elif self.game_state in ("win", "lose"):
                        self.game_state = "intro"
                        self.intro_anim_frame = 0
                    elif self.game_state == "playing":
                        # 空格发射
                        bullet = self.player.shoot(self.sound_mgr)
                        if bullet:
                            self.bullets.append(bullet)
            elif event.type == pygame.MOUSEMOTION:
                self.mouse_pos = event.pos
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if self.game_state == "intro":
                    # 初始页面按钮点击
                    if event.button == 1:
                        if self.start_btn_rect.collidepoint(event.pos):
                            self._on_start_click()
                        elif self.exit_btn_rect.collidepoint(event.pos):
                            self._on_exit_click()
                elif self.game_state == "paused":
                    # 暂停页面按钮点击
                    if event.button == 1:
                        if self.pause_restart_rect.collidepoint(event.pos):
                            self.init_level()
                        elif self.pause_menu_rect.collidepoint(event.pos):
                            self.game_state = "intro"
                            self.intro_anim_frame = 0
                            self.fade_alpha = 0
                            self.fade_state = None
                elif self.game_state == "playing":
                    if event.button == 1:      # 左键 = 指引移动
                        self.mouse_down = True
                    elif event.button == 3:    # 右键 = 发射
                        bullet = self.player.shoot(self.sound_mgr)
                        if bullet:
                            self.bullets.append(bullet)
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse_down = False
    
    def _on_start_click(self):
        """点击开始游戏按钮：触发黑场淡出→淡入→开始游戏"""
        if self.fade_state is not None:
            return  # 动画进行中不重复触发
        # 黑场动画完成后调用init_level开始游戏
        self.start_fade_out(callback=self.init_level)
    
    def _on_exit_click(self):
        """点击退出游戏按钮：关闭进程"""
        self.running = False
    
    def handle_input(self):
        if self.game_state != "playing" or not self.player or not self.player.alive:
            return
        
        keys = pygame.key.get_pressed()
        
        # 键盘移动 (WASD + 方向键)
        moved = False
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.player.move(UP, self.obstacles, self.tanks)
            moved = True
        elif keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.player.move(DOWN, self.obstacles, self.tanks)
            moved = True
        elif keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.player.move(LEFT, self.obstacles, self.tanks)
            moved = True
        elif keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.player.move(RIGHT, self.obstacles, self.tanks)
            moved = True
        
        # 鼠标左键按住 → 坦克朝鼠标方向移动
        if self.mouse_down and not moved:
            mx, my = self.mouse_pos
            px = self.player.x + self.player.width // 2
            py = self.player.y + self.player.height // 2
            dx = mx - px
            dy = my - py
            
            # 按主导方向移动
            if abs(dx) > abs(dy):
                if dx > 3:
                    self.player.move(RIGHT, self.obstacles, self.tanks)
                elif dx < -3:
                    self.player.move(LEFT, self.obstacles, self.tanks)
            else:
                if dy > 3:
                    self.player.move(DOWN, self.obstacles, self.tanks)
                elif dy < -3:
                    self.player.move(UP, self.obstacles, self.tanks)
        
        # 鼠标右键连发（按住右键持续射击）
        if self.mouse_shoot_cooldown > 0:
            self.mouse_shoot_cooldown -= 1
        mouse_buttons = pygame.mouse.get_pressed()
        if mouse_buttons[2] and self.mouse_shoot_cooldown <= 0:  # 右键按住
            bullet = self.player.shoot(self.sound_mgr)
            if bullet:
                self.bullets.append(bullet)
            self.mouse_shoot_cooldown = 15
    
    def update(self):
        # 黑场动画进行中：只更新fade，不更新游戏逻辑
        if self.fade_state is not None:
            self.update_fade()
            return
        
        if self.game_state == "intro":
            self.update_intro()
            return
        
        if self.game_state != "playing":
            # 更新特效仍然
            for exp in self.explosions:
                exp.update()
            for ft in self.floating_texts:
                ft.update()
            self.explosions = [e for e in self.explosions if e.alive]
            self.floating_texts = [f for f in self.floating_texts if f.alive]
            return
        
        # 更新坦克
        before_enemies = self.count_alive_enemies()
        for tank in self.tanks:
            if tank.alive:
                tank.update(self.obstacles, self.tanks, self.bullets, self.player, self.sound_mgr)
        
        # 更新子弹
        for bullet in self.bullets:
            bullet.update(self.obstacles, self.tanks, self.brick_debris)
        
        # 检测击杀
        for tank in self.tanks:
            if not tank.alive and not hasattr(tank, '_exploded'):
                tank._exploded = True
                cx = tank.x + tank.width // 2
                cy = tank.y + tank.height // 2
                self.explosions.append(Explosion(cx, cy, size=60 if tank.is_player else 45))
                
                if tank.is_player:
                    # 玩家死亡
                    self.sound_mgr.play('die')
                    self.floating_texts.append(FloatingText(cx, cy, "你被击毁了!", RED))
                    self.game_state = "lose"
                else:
                    # 敌人死亡
                    self.sound_mgr.play('kill')
                    self.score += 100
                    self.floating_texts.append(FloatingText(cx, cy, "+100", YELLOW))
        
        # 更新爆炸特效 & 漂浮文字 & 砖碎屑
        for exp in self.explosions:
            exp.update()
        for ft in self.floating_texts:
            ft.update()
        for d in self.brick_debris:
            d.update()
        
        # 清理
        self.bullets = [b for b in self.bullets if b.alive]
        self.explosions = [e for e in self.explosions if e.alive]
        self.floating_texts = [f for f in self.floating_texts if f.alive]
        self.brick_debris = [d for d in self.brick_debris if d.alive]
        # 保留已死亡坦克但不从列表移除（避免重复爆炸）
        
        # 检测波次
        alive_enemies = self.count_alive_enemies()
        if alive_enemies == 0 and self.player.alive:
            if self.wave < self.max_wave:
                self.wave += 1
                self.floating_texts.append(FloatingText(
                    SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2,
                    f"第 {self.wave} 波敌人来袭!", GREEN
                ))
                self.spawn_wave()
            else:
                self.game_state = "win"
                self.floating_texts.append(FloatingText(
                    SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2,
                    "胜利通关!", YELLOW
                ))
    
    def draw_obstacles(self):
        for obs in self.obstacles:
            pygame.draw.rect(self.screen, BROWN, obs)
    
    def draw_hud(self):
        # 顶部HUD半透明底
        HUD_H = 54
        hud_rect = pygame.Rect(0, 0, SCREEN_WIDTH, HUD_H)
        hud_surf = pygame.Surface((SCREEN_WIDTH, HUD_H), pygame.SRCALPHA)
        hud_surf.fill((0, 0, 0, 160))
        self.screen.blit(hud_surf, hud_rect)
        
        # ========== 左上角：LIZHI图标血条（替代爱心）==========
        max_icons = 3
        icon_gap = 8
        # 用已加载的图标（若加载失败回退到绘制爱心）
        icon_alive = self.lizhi_alive
        icon_dead = self.lizhi_dead
        if icon_alive is None:
            icon_size = 28
        else:
            icon_w, icon_h = icon_alive.get_size()
            icon_size = icon_w
        
        icons_start_x = 20
        icons_center_y = HUD_H // 2
        
        if self.player:
            current_hp = max(0, min(max_icons, self.player.health))
        else:
            current_hp = 0
        
        for i in range(max_icons):
            x = icons_start_x + i * (icon_size + icon_gap)
            alive = i < current_hp
            if icon_alive is not None:
                img = icon_alive if alive else icon_dead
                w, h = img.get_size()
                self.screen.blit(img, (x, icons_center_y - h // 2))
            else:
                cx = x + icon_size // 2
                draw_heart(self.screen, cx, icons_center_y, icon_size, alive=alive)
        
        # ========== 右上角：得分 ==========
        score_text = self.font_medium.render(f"{self.score}", True, YELLOW)
        score_x = SCREEN_WIDTH - score_text.get_width() - 20
        self.screen.blit(score_text, (score_x, 14))
        
        # ========== 顶部居中：波数 ==========
        wave_text = self.font_medium.render(f"{self.wave}", True, WHITE)
        wave_x = SCREEN_WIDTH // 2 - wave_text.get_width() // 2
        self.screen.blit(wave_text, (wave_x, 14))
    
    def draw_overlay(self, title, subtitle, color):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        
        title_surf = self.font_large.render(title, True, color)
        self.screen.blit(title_surf, 
                        (SCREEN_WIDTH // 2 - title_surf.get_width() // 2, 
                         SCREEN_HEIGHT // 2 - 80))
        
        sub_surf = self.font_medium.render(subtitle, True, WHITE)
        self.screen.blit(sub_surf, 
                         (SCREEN_WIDTH // 2 - sub_surf.get_width() // 2, 
                          SCREEN_HEIGHT // 2))
        
        hint_surf = self.font_small.render("按 空格/回车/ESC 重新开始 | ESC暂停", True, GRAY)
        self.screen.blit(hint_surf, 
                         (SCREEN_WIDTH // 2 - hint_surf.get_width() // 2, 
                          SCREEN_HEIGHT // 2 + 60))
    
    def draw_score_only(self, color):
        """结算页面：只显示一个大号分数数字，无任何文字"""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        
        score_str = f"{self.score}"
        big_font = pygame.font.Font(
            os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts', 'simhei.ttf'), 140)
        surf = big_font.render(score_str, True, color)
        self.screen.blit(surf, 
                        (SCREEN_WIDTH // 2 - surf.get_width() // 2,
                         SCREEN_HEIGHT // 2 - surf.get_height() // 2))
    
    def draw_controls_hint(self):
        """左下角操作提示面板"""
        lines = [
            ("移动键", WHITE),
            ("W A S D   ↑ ↓ ← →", WHITE),
            ("空格: 发射", YELLOW),
            ("左键: 移动  右键: 发射", (180, 220, 255)),
        ]
        line_h = 22
        panel_w = 240
        panel_h = len(lines) * line_h + 14
        y_start = SCREEN_HEIGHT - panel_h - 8
        
        panel = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        panel.fill((0, 0, 0, 130))
        self.screen.blit(panel, (8, y_start))
        
        for i, (text, color) in enumerate(lines):
            t = self.font_small.render(text, True, color)
            self.screen.blit(t, (18, y_start + 7 + i * line_h))
    
    def draw(self):
        # === 初始页面 ===
        if self.game_state == "intro":
            self.draw_intro()
            self._draw_cursor()
            pygame.display.flip()
            return
        
        # 背景
        self.screen.blit(self.background, (0, 0))
        
        # 障碍物
        self.draw_obstacles()
        
        # 子弹
        for b in self.bullets:
            b.draw(self.screen)
        
        # 坦克
        for t in self.tanks:
            t.draw(self.screen)
        
        # 爆炸
        for e in self.explosions:
            e.draw(self.screen)
        
        # 砖碎屑
        for d in self.brick_debris:
            d.draw(self.screen)
        
        # 漂浮文字
        for ft in self.floating_texts:
            ft.draw(self.screen, self.font_medium)
        
        # HUD
        self.draw_hud()
        
        # 覆盖层
        if self.game_state == "paused":
            # 暂停页
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            self.screen.blit(overlay, (0, 0))
            # "已暂停"大字
            paused_surf = self.font_large.render("已暂停", True, YELLOW)
            self.screen.blit(paused_surf,
                            (SCREEN_WIDTH // 2 - paused_surf.get_width() // 2,
                             SCREEN_HEIGHT // 2 - 100))
            # "点击ESC返回游戏"小字
            hint_surf = self.font_small.render("点击ESC返回游戏", True, WHITE)
            self.screen.blit(hint_surf,
                            (SCREEN_WIDTH // 2 - hint_surf.get_width() // 2,
                             SCREEN_HEIGHT // 2 - 45))
            # 两个按钮
            restart_hover = self.pause_restart_rect.collidepoint(self.mouse_pos)
            restart_color = (90, 200, 90) if restart_hover else (60, 160, 60)
            self._draw_button(self.pause_restart_rect, "重新游戏", restart_color, 255)
            menu_hover = self.pause_menu_rect.collidepoint(self.mouse_pos)
            menu_color = (200, 180, 80) if menu_hover else (160, 140, 60)
            self._draw_button(self.pause_menu_rect, "退出至菜单", menu_color, 255)
        elif self.game_state == "win":
            self.draw_score_only(GREEN)
        elif self.game_state == "lose":
            self.draw_score_only(RED)
        
        # 黑场动画（playing/win/lose状态过渡期间）
        if self.fade_alpha > 0 and self.game_state != "intro":
            fade_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            fade_surf.fill(BLACK)
            fade_surf.set_alpha(self.fade_alpha)
            self.screen.blit(fade_surf, (0, 0))
            # "加油"文字
            if self.jiayou_alpha > 0:
                jiayou_surf = self.font_large.render("加油", True, YELLOW)
                jx = SCREEN_WIDTH // 2 - jiayou_surf.get_width() // 2
                jy = SCREEN_HEIGHT // 2 - jiayou_surf.get_height() // 2
                jiayou_surf.set_alpha(self.jiayou_alpha)
                self.screen.blit(jiayou_surf, (jx, jy))
        
        # 鼠标指引方向指示器（左键按住时显示）
        if self.game_state == "playing" and self.mouse_down:
            mx, my = self.mouse_pos
            pygame.draw.circle(self.screen, (100, 255, 100), (mx, my), 6, 2)
        
        # 自定义瞄准镜光标
        self._draw_cursor()
        
        pygame.display.flip()
    
    def _draw_cursor(self):
        """绘制自定义瞄准镜光标"""
        mx, my = self.mouse_pos
        # 外圆
        pygame.draw.circle(self.screen, (255, 50, 50), (mx, my), 12, 2)
        # 十字线
        pygame.draw.line(self.screen, (255, 50, 50), (mx - 16, my), (mx - 6, my), 2)
        pygame.draw.line(self.screen, (255, 50, 50), (mx + 6, my), (mx + 16, my), 2)
        pygame.draw.line(self.screen, (255, 50, 50), (mx, my - 16), (mx, my - 6), 2)
        pygame.draw.line(self.screen, (255, 50, 50), (mx, my + 6), (mx, my + 16), 2)
        # 中心点
        pygame.draw.circle(self.screen, (255, 255, 255), (mx, my), 2)
    
    def run(self):
        while self.running:
            self.handle_events()
            self.handle_input()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        pygame.quit()
        sys.exit(0)

# ==================== 启动 ====================
if __name__ == "__main__":
    print("=" * 50)
    print("坦克大战 - HYW原创版本")
    print("=" * 50)
    print("操作说明:")
    print("  - WASD / 方向键 : 移动坦克")
    print("  - 空格 / 鼠标左键 : 发射篮球子弹")
    print("  - M键 : 切换键盘/鼠标瞄准模式")
    print("  - ESC键 : 暂停/重新开始")
    print("目标:")
    print("  - 击毁所有敌方坦克，通过全部5波关卡")
    print("=" * 50)
    
    try:
        game = Game()
        game.run()
    except Exception as e:
        import traceback
        print(f"\n[错误] 游戏运行出错: {e}")
        traceback.print_exc()
        pygame.quit()
        sys.exit(1)
